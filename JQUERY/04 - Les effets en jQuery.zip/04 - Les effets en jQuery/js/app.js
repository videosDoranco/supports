$("document").ready(function(){

    // hide
    $(".hide").click(function(){
        $(this).next().hide(1000, function(){
            $(this).prev().css("color", "red");
        });
    });

    // show
    $(".show").click(function(){
        $(this).next().show();
    });

    // fadein
    $(".fadein").click(function(){
        $(this).next().fadeIn(4000, function(){
            alert("Effect done !");
        });
    });

    // fadeout
    $(".fadeout").click(function(){
        $(this).next().fadeOut();
    });

});