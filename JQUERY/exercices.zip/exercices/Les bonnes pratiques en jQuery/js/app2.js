let app = {};

// IIFE

(function ($) {

    "use strict";

    /*******************
    Predefined variables
    *******************/

    let $window = $(window),
        $document = $(document),
        $body = $("body");

    app.start = function () {

        $(".drum").click(function () {
            let letterClicked = $(this).text();
            app.makeSound(letterClicked);
        });

        $(document).keypress(function (event) {
            let letteredPressed = event.key;
            app.makeSound(letteredPressed);
        });
    };

    app.makeSound = function (letterClickedOrPressed) {bonn

        switch (letterClickedOrPressed) {

            case "w":
                var tom1 = new Audio("sounds/w.mp3");
                tom1.play();
                break;

            case "a":
                var tom1 = new Audio("sounds/a.mp3");
                tom1.play();
                break;

            case "s":
                var tom1 = new Audio("sounds/s.mp3");
                tom1.play();
                break;

            case "d":
                var tom1 = new Audio("sounds/d.mp3");
                tom1.play();
                break;

            case "j":
                var tom1 = new Audio("sounds/j.mp3");
                tom1.play();
                break;

            case "k":
                var tom1 = new Audio("sounds/k.mp3");
                tom1.play();
                break;

            case "l":
                var tom1 = new Audio("sounds/l.mp3");
                tom1.play();
                break;
        }

        app.buttonAnimation(letterClickedOrPressed);

    };

    app.buttonAnimation = function (letterClickedOrPressed) {
        $("." + letterClickedOrPressed).addClass("pressed");


        setTimeout(function () {
            $("." + letterClickedOrPressed).removeClass("pressed");
        }, 200);
    };

    $document.ready(function () {
        app.start();
    });


})(jQuery);