$(document).ready(function () {

    $(this).click(function (event) {

        // POSITIONS
        let x = event.pageX;
        let y = event.pageY;

        // RANDOM WIDTH HEIGHT
        let width_height_random = Math.floor(Math.random() * 100) + 50;

        // Center the cursor in the circle
        x = x - (width_height_random / 2);
        y = y - (width_height_random / 2);

        // RANDOM COLOR
        let list_colors = ["#1abc9c", "#2ecc71", "#3498db", "#9b59b6", "#34495e", "#16a085", "#27ae60",
            "#2980b9", "#8e44ad", "#2c3e50", "#f1c40f", "#e67e22", "#e74c3c", "#ecf0f1", "#95a5a6",
            "#f39c12", "#d35400", "#c0392b", "#bdc3c7", "#7f8c8d"];

        let random_color_index = Math.floor(Math.random() * 19) + 0;
        let color = list_colors[random_color_index];

        console.log("X:" + x + "Y:" + y);
        console.log("width_height:" + width_height_random);
        console.log("color:" + color);

        // CIRCLE
        let circle = "<div style='width:" + width_height_random + "px;height:" + width_height_random + "px;background-color:" + color + ";border-radius:50%;position:absolute;top:" + y + "px;left:" + x + "px;'> </div>";

        // Add the circle to the DOMvi
        $("body").append(circle);

        let windowHeight = $(window).height();

        $("div").last().animate({
            top: windowHeight - width_height_random
        }, 2000, function () {
            $(this).fadeOut();
        });

    });

});