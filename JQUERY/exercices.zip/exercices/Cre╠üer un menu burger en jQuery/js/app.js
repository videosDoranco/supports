$(document).ready(function () {

    $(".cross").hide();
    $(".menu").hide();

    $(".hamburger").click(function () {
        $(".menu").slideToggle("slow", function () {
            $(".hamburger").hide();
            $(".cross").show();
        });
    });

    $(".cross").click(function () {
        $(".menu").slideToggle("slow", function () {
            $(".cross").hide();
            $(".hamburger").show();
        });
    });

    $("li").hover(function(){
        $(this).css("font-size", "1.5rem");
    }, function(){
        $(this).css("font-size", "0.8rem");
    });

});