let app = {};

(function ($) {

    "use strict";

    // Predefined variables
    let $window = $(window),
        $document = $(document),
        $body = $("body");


    app.getTooltip = function (elemHTML) {
        return elemHTML.nextAll("span.tooltip").first();
    };

    app.sexe = function (idElemHTML) {
        let sexe = $("input[name='" + idElemHTML + "']"),
            tooltip = app.getTooltip($("#labelSexeF"));

        if (sexe.is(":checked")) {
            tooltip.hide();
            return true;
        } else {
            tooltip.show();
            return false;
        }
    };

    app.lastName = function (idElemHTML) {
        console.log("checking lastName or firstName or login or pwd1");

        let elemHTML = $("#" + idElemHTML),
            tooltip = app.getTooltip(elemHTML),
            nbrLimitCar;

        if (idElemHTML == "login") {
            nbrLimitCar = 4;
        } else if (idElemHTML == "pwd1") {
            nbrLimitCar = 6;
        } else {
            nbrLimitCar = 2;
        }

        if (elemHTML.val().length >= nbrLimitCar) {
            elemHTML.addClass("correct");
            elemHTML.removeClass("incorrect");
            elemHTML.nextAll("span:first").hide();
            return true;
        } else {
            elemHTML.addClass("incorrect");
            elemHTML.removeClass("correct");
            elemHTML.nextAll("span:first").show();
            return false;
        }

    };

    app.firstName = app.lastName;

    app.age = function (idElemHTML) {
        console.log("checking age");

        let age = $("#" + idElemHTML),
            tooltip = app.getTooltip(age);


        if (age.val() >= 5 && age.val() <= 140) {
            tooltip.hide();
            age.removeClass("incorrect");
            age.addClass("correct");
            return true;
        } else {
            tooltip.show();
            age.removeClass("correct");
            age.addClass("incorrect");
            return false;
        }

    };

    app.login = app.lastName;

    app.pwd1 = app.lastName;

    app.pwd2 = function () {
        console.log("checking pwd2");

        let pwd1 = $("#pwd1"),
            pwd2 = $("#pwd2"),
            tooltip = app.getTooltip(pwd2);

        if (pwd2.val().length > 0 && pwd2.val() == pwd1.val()) {
            pwd2.removeClass("incorrect");
            pwd2.addClass("correct");
            tooltip.hide();
            return true;
        } else {
            pwd2.removeClass("correct");
            pwd2.addClass("incorrect");
            tooltip.show();
            return false;
        }

    };

    app.country = function () {
        console.log("checking country");

        let country = $("#country"),
            countrySelectedOption = $("#country option:selected"),
            tooltip = app.getTooltip(country);

        if (countrySelectedOption.val() != "none") {
            tooltip.hide();
            return true;
        } else {
            tooltip.show();
            return false;
        }

    };

    app.start = function () {

        console.log("start control");
        $(".tooltip").hide();

        // EVENT SUBMIT 
        $("#myForm").submit(function (e) {

            let control = true;

            //console.log("submit");
            e.preventDefault();

            // app.lastName();
            // app.firstName();
            // app.age();
            // ...

            $.each(app, function (index, value) {

                if (index != "getTooltip" && index != "start") {
                    // console.log(index);
                    // console.log("app['" + index + "']('" + index + "')");
                    control = app[index](index) && control;
                    console.log(control);
                }

            });

            if (control) {
                alert("Control OK");
            } else {
                alert("Control not OK");
            }

        });

        // EVENT KEYUP
        $("input:not(:submit, :reset)").keyup(function () {
            // console.log("keyup");
            let id = $(this).attr("id");
            app[id](id); // ex : app.lastName("lastName");

        });

    };


    $document.ready(function () {
        app.start();
    });

})(jQuery);