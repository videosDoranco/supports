$("document").ready(function () {

    $(".tooltip").hide();

    function checkLastName(elemHTML) {

        let value = elemHTML.val();

        // No error
        if (value.length >= 2) {
            elemHTML.addClass("correct");
            elemHTML.removeClass("incorrect");
            elemHTML.nextAll("span:first").hide();
            return true;
        } else {
            elemHTML.addClass("incorrect");
            elemHTML.removeClass("correct");
            elemHTML.nextAll("span:first").show();
            return false;
        }

    }

    // EVENT SUBMIT 
    $("#myForm").submit(function (e) {

        console.log("submit");
        e.preventDefault();

        if (checkLastName($("#lastName"))) {
            alert("No Error, submit done !");
        } else {
            alert("Errors in your form !");
        }

    });

    // EVENT KEYUP
    $("#lastName").keyup(function () {
        console.log("keyup");
        chekLastName($(this));
    });


});