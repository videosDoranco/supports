$(document).ready(function () {

    // HOVER
    $("img").hover(function () {
        $(this).animate({
            opacity: "0.4"
        }, 200);
    }, function () {
        $(this).animate({
            opacity: "1"
        }, 200);
    });

    // CLICK
    $("button").click(function () {
        //$("img").toggle(2000, "linear");
        $("img").fadeToggle();
    });

    $(this).keypress(function (e) {
        let keypressed = e.key;
        console.log(keypressed);
        $("." + keypressed).fadeToggle(200);
    });

});