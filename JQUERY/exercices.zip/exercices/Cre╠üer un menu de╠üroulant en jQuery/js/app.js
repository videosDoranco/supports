$(document).ready(function () {

    $("li").hover(function () {
        $(this).find("ul").slideToggle();
    });

});