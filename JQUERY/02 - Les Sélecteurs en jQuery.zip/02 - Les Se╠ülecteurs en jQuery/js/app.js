$(document).ready(function () {
    console.log("Hello world !");

    // CLASS SELECTOR

    // console.log("class : ", $(".myClass"));
    // console.log("class : ", $(".myClass").eq(0).text());
    $(".myClass").eq(0).text("my new text");

    //let elems = document.getElementsByClassName("myClass")[0].innerHTML = "hello world";
    //console.log(elems);

    // ID SELECTOR
    $("#myId2").css("color", "red");
    //document.getElementById("myId2").style.color = "yellow";

    // TAG SELECTOR
    $("p").css("text-transform", "uppercase");

    // let listP = document.getElementsByTagName("p");
    // console.log(listP);
    // for (let i = 0; i < listP.length; i++) {
    //     listP[i].innerHTML = listP[i].innerHTML.toUpperCase();
    // }

    $("p").last().text("My last P");

    // ATTRIBUTE SELECTOR
    $("img[src='img/2.png']").css("width", "400px");

    // MULTIPLE SELECTORS
    $("p, span, div").css("color", "brown");

    // NAVIGATION
    $("#myPgh").parent().find("span").css("color", "red");
    // console.log($("#myPgh").next());

    // console.log($("#container").children());

    // TYPE
    console.log($(":text"));
    console.log($("input[type='text']"));


});