console.log("Comparison Operators");

// == (value)

var comparison1 = "text" == "text";
console.log("comparison1 :" + comparison1);

comparison1 = "my text" == "text";
console.log("comparison1 :" + comparison1);

comparison1 = "2" == "2";
console.log("comparison1 :" + comparison1);

comparison1 = 2 == "2";
console.log("comparison1 :" + comparison1);

// === (value) && (Type)
var comparison2 = 2 === "2";
console.log("comparison2 :" + comparison2);

// !=

var comparison3 = 3 != 4;
console.log("comparison3 :" + comparison3);

comparison3 = 4 != 4;
console.log("comparison3 :" + comparison3);

// !==
var comparison4 = 4 !== "4";
console.log("comparison4 :" + comparison4);

var comparison5 = 4 !== 4;
console.log("comparison5 :" + comparison5);



// >
var comparison6 = 3 > 1;
console.log("comparison6 :" + comparison6);

// <
var comparison7 = 3 < 4;
console.log("comparison7 :" + comparison7);

// >=
var comparison8 = 2 >= 2;
console.log("comparison8 :" + comparison8);

// <=
var comparison9 = 3 <= 4;
console.log("comparison9 :" + comparison9);
