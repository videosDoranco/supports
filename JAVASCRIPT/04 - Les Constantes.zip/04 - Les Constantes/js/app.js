console.log("Les constantes");

const MA_CONSTANTE = 2; // déclaration

MA_CONSTANTE = 4;
